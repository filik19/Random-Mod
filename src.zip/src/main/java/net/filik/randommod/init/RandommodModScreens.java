/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.filik.randommod.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.filik.randommod.client.gui.DevactScreen;

@EventBusSubscriber(Dist.CLIENT)
public class RandommodModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(RandommodModMenus.DEVACT.get(), DevactScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}