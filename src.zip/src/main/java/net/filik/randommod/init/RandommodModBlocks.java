/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.filik.randommod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.filik.randommod.block.CzeciablockBlock;
import net.filik.randommod.RandommodMod;

import java.util.function.Function;

public class RandommodModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(RandommodMod.MODID);
	public static final DeferredBlock<Block> CZECIABLOCK;
	static {
		CZECIABLOCK = register("czeciablock", CzeciablockBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}