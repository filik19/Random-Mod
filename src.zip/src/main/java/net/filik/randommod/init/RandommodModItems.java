/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.filik.randommod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.filik.randommod.item.CzswordItem;
import net.filik.randommod.item.CzpickItem;
import net.filik.randommod.RandommodMod;

import java.util.function.Function;

public class RandommodModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(RandommodMod.MODID);
	public static final DeferredItem<Item> CZECIABLOCK;
	public static final DeferredItem<Item> CZPICK;
	public static final DeferredItem<Item> CZSWORD;
	static {
		CZECIABLOCK = block(RandommodModBlocks.CZECIABLOCK);
		CZPICK = register("czpick", CzpickItem::new);
		CZSWORD = register("czsword", CzswordItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}