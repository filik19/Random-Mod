/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.filik.randommod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.filik.randommod.RandommodMod;

@EventBusSubscriber
public class RandommodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RandommodMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> RANDOMMOD = REGISTRY.register("randommod",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.randommod.randommod")).icon(() -> new ItemStack(RandommodModBlocks.CZECIABLOCK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RandommodModItems.CZPICK.get());
				tabData.accept(RandommodModItems.CZSWORD.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(RandommodModItems.CZPICK.get());
			tabData.accept(RandommodModItems.CZSWORD.get());
		}
	}
}