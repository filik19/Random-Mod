package net.filik.randommod.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class CzpickItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 100, 255f, 0, 2, TagKey.create(Registries.ITEM, ResourceLocation.parse("randommod:czpick_repair_items")));

	public CzpickItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 39f, -3.9454783448f));
	}
}